Image procesing: 17207946488_c621ce7830_m.jpg
Number of faces recognised on the image: 1
The error(number of faces missed) made on this image is: 0
Position and confident socre: 120 28 62 62 7.633954
Image procesing: 5123265912_094e68529a_m.jpg
Number of faces recognised on the image: 0
The error(number of faces missed) made on this image is: 4
#####################################################
The number of photos is:  43
The total of faces on them is: 86
The number of faces that the model detects is: 41
